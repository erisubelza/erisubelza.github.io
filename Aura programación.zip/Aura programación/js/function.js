

document.getElementById('button-1').onclick=function () { 
    console.log("Capturamos el evento click");
    document.getElementById("demo").innerHTML = "No hay proyectos recientes"
}
